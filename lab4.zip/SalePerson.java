public class SalePerson {
    private String firstName;
    private String lastName;
    private int totalSales;
}
